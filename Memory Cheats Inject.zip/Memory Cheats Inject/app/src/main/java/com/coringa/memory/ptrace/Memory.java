package com.coringa.memory.ptrace;

import android.os.Build;
import java.io.File;
import java.lang.reflect.Constructor;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class Memory {
	
	
	public static native int mprotect(long addr, long lenz);
    public static native long sysconf();
	
	
	
    static long findLocation() throws Exception {
        Scanner scan = new Scanner(new File("/proc/self/maps"));
        long location = -1;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] parts = line.split(" ");
            if (parts[parts.length - 1].contains("libil2cpp.so") && parts[1].contains("x")) {
                location = Long.parseLong(parts[0].substring(0, parts[0].indexOf("-")), 16);
                break;
            }
        }
        scan.close();
        return location;

    }
    static long findUnityLocation() throws Exception {
        Scanner scan = new Scanner(new File("/proc/self/maps"));
        long location = -1;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] parts = line.split(" ");
            if (parts[parts.length - 1].contains("libunity.so") && parts[1].contains("x")) {
                location = Long.parseLong(parts[0].substring(0, parts[0].indexOf("-")), 16);
                break;
            }
        }
        scan.close();
        return location;
    }
    static ByteBuffer createByteBuffer(long address, long length) throws Exception {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            return createDirectByteBufferNew(address, length);
        }
        Constructor cons = Class.forName("java.nio.ReadWriteDirectByteBuffer").getDeclaredConstructor(Integer.TYPE, Integer.TYPE);
        cons.setAccessible(true);
        return (ByteBuffer) cons.newInstance((int) address, (int) length);
    }

    private static ByteBuffer createDirectByteBufferNew(long address, long length) throws Exception {
        Constructor cons = Class.forName("java.nio.DirectByteBuffer").getDeclaredConstructor(Long.TYPE, Integer.TYPE);
        cons.setAccessible(true);
        return (ByteBuffer) cons.newInstance(address, (int) length);
    }
    static long findLength(String loc) {
        return new File(loc).length();
    }

    public static void write(int offset, String hex, ByteBuffer buffer1) {
        buffer1.position(offset);
        buffer1.put(Hex2b(hex));
    }
    private static byte[] Hex2b(String hex) {
        if (hex.contains(" ")) {
            hex = hex.replace(" ", "");
        }
        if (hex == null) throw new IllegalArgumentException("hex == null");
        if (hex.length() % 2 != 0)
            throw new IllegalArgumentException("Unexpected hex string: " + hex);

        byte[] result = new byte[hex.length() / 2];
        for (int i = 0; i < result.length; i++) {
            int d1 = decodeHexDigit(hex.charAt(i * 2)) << 4;
            int d2 = decodeHexDigit(hex.charAt(i * 2 + 1));
            result[i] = (byte) (d1 + d2);
        }
        return result;
    }
    private static int decodeHexDigit(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        throw new IllegalArgumentException("Unexpected hex digit: " + c);

    }
}
