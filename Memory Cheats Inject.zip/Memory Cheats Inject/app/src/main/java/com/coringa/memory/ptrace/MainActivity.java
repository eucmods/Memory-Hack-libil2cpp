package com.coringa.memory.ptrace;
 
import android.app.Activity;
import android.os.Bundle;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {

	private static ByteBuffer lib;
	
	static{
		Memory.write(0xAC0CE, "0A 00 E3 1E FF 2F E1", lib);
	}
	
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
    }
}
